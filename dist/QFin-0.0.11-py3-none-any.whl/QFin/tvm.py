class Annuity:

    def __init__():
        pass


class Perpetuity:

    def __init__():
        pass


class TVM:

    def __init__():
        pass
